package com.example.data

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.AlertBgGreen
import com.example.ui.theme.AlertBgOrange
import com.example.ui.theme.AlertBgRed
import com.example.ui.theme.AlertBgYellow
import com.example.ui.theme.AlertLevelGreen
import com.example.ui.theme.AlertLevelOrange
import com.example.ui.theme.AlertLevelRed
import com.example.ui.theme.AlertLevelYellow

enum class AlertLevel(
    val label: String,
    val emoji: String,
    val color: Color,
    val bgColor: Color,
    val severityTitle: String
) {
    YELLOW(
        label = "Amarillo",
        emoji = "🟡",
        color = AlertLevelYellow,
        bgColor = AlertBgYellow,
        severityTitle = "Aviso Amarillo - Riesgo"
    ),
    ORANGE(
        label = "Naranja",
        emoji = "🟠",
        color = AlertLevelOrange,
        bgColor = AlertBgOrange,
        severityTitle = "Aviso Naranja - Riesgo Importante"
    ),
    RED(
        label = "Rojo",
        emoji = "🔴",
        color = AlertLevelRed,
        bgColor = AlertBgRed,
        severityTitle = "Aviso Rojo - Riesgo Extremo"
    ),
    GREEN(
        label = "Verde",
        emoji = "🟢",
        color = AlertLevelGreen,
        bgColor = AlertBgGreen,
        severityTitle = "Sin avisos meteorológicos"
    )
}

enum class Province(
    val displayName: String,
    val shortName: String,
    val capitalCity: String
) {
    CASTELLON("Castellón / Castelló", "Castellón", "Castelló de la Plana"),
    VALENCIA("Valencia / València", "Valencia", "València"),
    ALICANTE("Alicante / Alacant", "Alicante", "Alacant")
}

data class WeatherAlert(
    val id: String,
    val level: AlertLevel,
    val province: Province,
    val zone: String,
    val phenomenon: String,
    val description: String,
    val threshold: String,
    val timeRange: String,
    val recommendations: List<String>
)

data class ProvinceStatus(
    val province: Province,
    val maxAlert: AlertLevel,
    val activeAlertsCount: Int,
    val summaryText: String,
    val tempRange: String,
    val currentTemp: String,
    val skyDescription: String
)

data class HourlyForecast(
    val time: String,
    val temp: String,
    val pop: String, // Probabilidad precipitación
    val icon: String,
    val condition: String
)

data class DailyForecast(
    val day: String,
    val dateText: String,
    val tempMax: String,
    val tempMin: String,
    val condition: String,
    val pop: String,
    val alertLevel: AlertLevel
)

object DemoDataSource {
    // Alertas meteorológicas de demostración (DEMO)
    val demoAlerts = listOf(
        WeatherAlert(
            id = "ALERT-001",
            level = AlertLevel.RED,
            province = Province.VALENCIA,
            zone = "Litoral Sur de Valencia",
            phenomenon = "Precipitaciones acumuladas torrenciales",
            description = "Simulación preventiva de precipitaciones muy intensas y persistentes con riesgo de crecidas e inundaciones en zonas bajas y barrancos.",
            threshold = "Hasta 180 mm en 12 horas / 50 mm en 1 hora",
            timeRange = "Hoy 16:00 - Mañana 10:00",
            recommendations = listOf(
                "Evitar cualquier desplazamiento innecesario en vehículo.",
                "No cruzar vados, cauces secos ni zonas inundables bajo ningún concepto.",
                "Permanecer en pisos altos si se encuentra cerca de barrancos.",
                "Seguir en todo momento los canales oficiales de Emergencias 112 CV."
            )
        ),
        WeatherAlert(
            id = "ALERT-002",
            level = AlertLevel.ORANGE,
            province = Province.VALENCIA,
            zone = "Interior Norte y Central de Valencia",
            phenomenon = "Tormentas fuertes con granizo",
            description = "Tormentas organizadas de intensidad fuerte a muy fuerte acompañadas de aparato eléctrico y probable granizo de tamaño superior a 2 cm.",
            threshold = "Rachas muy fuertes asociadas y 40 mm/1h",
            timeRange = "Hoy 15:00 - Hoy 23:00",
            recommendations = listOf(
                "Asegurar puertas, ventanas y toldos.",
                "Alejarse de árboles altos, postes y elementos metálicos en exteriores.",
                "Revisar desagües y bajantes comunitarios."
            )
        ),
        WeatherAlert(
            id = "ALERT-003",
            level = AlertLevel.ORANGE,
            province = Province.CASTELLON,
            zone = "Litoral de Castellón",
            phenomenon = "Fenómenos costeros y temporal de levante",
            description = "Viento del nordeste con rachas de 60 a 75 km/h (fuerza 7 a 8) levantando mar gruesa con olas de 3 a 4,5 metros en aguas costeras.",
            threshold = "Olas de 3,5 a 4,5 metros mar adentro",
            timeRange = "Hoy 12:00 - Mañana 18:00",
            recommendations = listOf(
                "No acercarse a espigones, rompeolas ni paseos marítimos batidos por el oleaje.",
                "Retirar embarcaciones a amarres seguros en puertos protegidos.",
                "No practicar deportes náuticos ni pesca costera."
            )
        ),
        WeatherAlert(
            id = "ALERT-004",
            level = AlertLevel.YELLOW,
            province = Province.CASTELLON,
            zone = "Interior Norte de Castellón (Els Ports y Maestrat)",
            phenomenon = "Rachas máximas de viento",
            description = "Viento del noroeste con rachas que pueden alcanzar puntualmente los 70-80 km/h en zonas altas y collados.",
            threshold = "Rachas de hasta 75 km/h",
            timeRange = "Hoy 08:00 - Mañana 00:00",
            recommendations = listOf(
                "Precaución al volante, especialmente al adelantar camiones o al salir de túneles.",
                "Retirar tiestos y macetas de cornisas y balcones."
            )
        ),
        WeatherAlert(
            id = "ALERT-005",
            level = AlertLevel.YELLOW,
            province = Province.ALICANTE,
            zone = "Litoral Norte y Central de Alicante",
            phenomenon = "Fenómenos costeros moderados",
            description = "Viento del nordeste fuerza 6 a 7 con mar de fondo y oleaje de 2 a 3 metros en zonas abiertas a levante.",
            threshold = "Olas de 2,5 metros",
            timeRange = "Hoy 18:00 - Mañana 12:00",
            recommendations = listOf(
                "Atención a las banderas en playas y accesos costeros.",
                "Evitar aparcar vehículos junto al rompiente de olas."
            )
        )
    )

    val provinceStatuses = listOf(
        ProvinceStatus(
            province = Province.VALENCIA,
            maxAlert = AlertLevel.RED,
            activeAlertsCount = 2,
            summaryText = "Aviso Rojo activo en Litoral Sur por lluvias torrenciales y tormentas.",
            tempRange = "15°C / 21°C",
            currentTemp = "18°C",
            skyDescription = "Lluvioso con tormenta"
        ),
        ProvinceStatus(
            province = Province.CASTELLON,
            maxAlert = AlertLevel.ORANGE,
            activeAlertsCount = 2,
            summaryText = "Aviso Naranja por temporal marítimo en litoral y viento en interior.",
            tempRange = "13°C / 19°C",
            currentTemp = "16°C",
            skyDescription = "Nuboso y ventoso"
        ),
        ProvinceStatus(
            province = Province.ALICANTE,
            maxAlert = AlertLevel.YELLOW,
            activeAlertsCount = 1,
            summaryText = "Aviso Amarillo por oleaje en litoral norte. Interior despejado.",
            tempRange = "17°C / 24°C",
            currentTemp = "22°C",
            skyDescription = "Intervalos nubosos"
        )
    )

    val hourlyDemo = listOf(
        HourlyForecast("Ahora", "18°C", "90%", "🌧️", "Lluvia moderada"),
        HourlyForecast("16:00", "17°C", "95%", "⛈️", "Tormenta fuerte"),
        HourlyForecast("18:00", "16°C", "90%", "🌧️", "Lluvia intensa"),
        HourlyForecast("20:00", "15°C", "70%", "🌦️", "Chubascos"),
        HourlyForecast("22:00", "14°C", "40%", "☁️", "Nublado"),
        HourlyForecast("00:00", "14°C", "20%", "☁️", "Nublado"),
        HourlyForecast("02:00", "13°C", "10%", "⛅", "Parcialmente nuboso"),
        HourlyForecast("06:00", "13°C", "10%", "⛅", "Brumas matinales"),
        HourlyForecast("09:00", "15°C", "5%", "🌤️", "Despejando")
    )

    val dailyDemo = listOf(
        DailyForecast("Hoy", "Jueves 17", "21°C", "14°C", "Lluvia y tormenta", "95%", AlertLevel.RED),
        DailyForecast("Mañana", "Viernes 18", "23°C", "13°C", "Mejoría gradual", "35%", AlertLevel.YELLOW),
        DailyForecast("Sábado", "Sábado 19", "25°C", "14°C", "Soleado con brisa", "10%", AlertLevel.GREEN),
        DailyForecast("Domingo", "Domingo 20", "26°C", "15°C", "Despejado", "5%", AlertLevel.GREEN),
        DailyForecast("Lunes", "Lunes 21", "24°C", "14°C", "Intervalos nubosos", "15%", AlertLevel.GREEN)
    )
}
