package com.example.data.aemet

import com.example.data.AlertLevel
import com.example.data.Province

data class AemetAlert(
    val id: String,
    val level: AlertLevel,
    val province: Province,
    val zoneName: String,
    val zoneCode: String,
    val phenomenon: String,
    val description: String,
    val value: String?,
    val probability: String?,
    val onsetRaw: String,
    val onsetFormatted: String,
    val expireRaw: String,
    val expireFormatted: String,
    val certainty: String?,
    val recommendations: List<String>
)

object AemetConstants {
    const val SOURCE_LABEL = "Fuente: AEMET"
    const val SOURCE_FULL = "Fuente: AEMET (Agencia Estatal de Meteorología)"
    const val NO_ALERTS_MESSAGE = "No hay avisos meteorológicos activos"

    // Mapping of official zone codes for Comunitat Valenciana
    val CV_ZONES: Map<String, Pair<Province, String>> = mapOf(
        // Alicante (7703)
        "770301" to Pair(Province.ALICANTE, "Litoral norte de Alicante"),
        "770301C" to Pair(Province.ALICANTE, "Litoral norte de Alicante - Costa"),
        "770302" to Pair(Province.ALICANTE, "Interior de Alicante"),
        "770303" to Pair(Province.ALICANTE, "Litoral sur de Alicante"),
        "770303C" to Pair(Province.ALICANTE, "Litoral sur de Alicante - Costa"),

        // Castellón (7712)
        "771201" to Pair(Province.CASTELLON, "Interior norte de Castellón"),
        "771202" to Pair(Province.CASTELLON, "Litoral norte de Castellón"),
        "771202C" to Pair(Province.CASTELLON, "Litoral norte de Castellón - Costa"),
        "771203" to Pair(Province.CASTELLON, "Interior sur de Castellón"),
        "771204" to Pair(Province.CASTELLON, "Litoral sur de Castellón"),
        "771204C" to Pair(Province.CASTELLON, "Litoral sur de Castellón - Costa"),

        // Valencia (7746)
        "774601" to Pair(Province.VALENCIA, "Interior norte de Valencia"),
        "774602" to Pair(Province.VALENCIA, "Litoral norte de Valencia"),
        "774602C" to Pair(Province.VALENCIA, "Litoral norte de Valencia - Costa"),
        "774603" to Pair(Province.VALENCIA, "Interior sur de Valencia"),
        "774604" to Pair(Province.VALENCIA, "Litoral sur de Valencia"),
        "774604C" to Pair(Province.VALENCIA, "Litoral sur de Valencia - Costa")
    )
}
