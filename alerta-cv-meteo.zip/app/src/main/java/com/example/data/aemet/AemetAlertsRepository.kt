package com.example.data.aemet

import com.example.data.AlertLevel
import com.example.data.Province
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.TimeUnit

class AemetAlertsRepository(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()
) {

    companion object {
        private const val BASE_URL = "https://www.aemet.es/es/api-eltiempo"
        private const val USER_AGENT = "Mozilla/5.0 (Android; Mobile; AlertaCVMeteo/1.0)"
    }

    /**
     * Fetches official AEMET alerts for Comunitat Valenciana.
     * @param dayOffset "D+0" for today, "D+1" for tomorrow
     */
    suspend fun fetchValencianAlerts(dayOffset: String = "D+0"): Result<List<AemetAlert>> = withContext(Dispatchers.IO) {
        try {
            // Step 1: Query the timeline endpoint to get the official reference timestamp
            val timelineDate = fetchTimelineDate()

            // Step 2: Query the summary alerts endpoint for Comunitat Valenciana
            val encodedDate = URLEncoder.encode(timelineDate, "UTF-8")
            val alertsUrl = "$BASE_URL/resumen-lista-avisos/VAL/$encodedDate/$dayOffset"

            val request = Request.Builder()
                .url(alertsUrl)
                .header("User-Agent", USER_AGENT)
                .header("Accept", "application/json")
                .build()

            val response = client.newCall(request).execute()
            if (!response.isSuccessful) {
                return@withContext Result.failure(Exception("Error HTTP ${response.code} al consultar AEMET"))
            }

            val bodyString = response.body?.string()
                ?: return@withContext Result.failure(Exception("Respuesta vacía de AEMET"))

            val alerts = parseAemetJson(bodyString)
            Result.success(alerts)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun fetchTimelineDate(): String {
        try {
            val timelineUrl = "$BASE_URL/timeline-avisos/VAL"
            val request = Request.Builder()
                .url(timelineUrl)
                .header("User-Agent", USER_AGENT)
                .header("Accept", "application/json")
                .build()

            val response = client.newCall(request).execute()
            if (response.isSuccessful) {
                val body = response.body?.string()
                if (!body.isNullOrBlank()) {
                    val json = JSONObject(body)
                    val horarios = json.optJSONArray("horarios_penbal")
                    if (horarios != null && horarios.length() > 0) {
                        val firstTimestamp = horarios.optString(0)
                        if (firstTimestamp.isNotBlank()) {
                            return firstTimestamp
                        }
                    }
                }
            }
        } catch (_: Exception) {
            // Fallback to local system time in ISO-8601 with Madrid timezone
        }

        val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:00:00XXX", Locale.getDefault()).apply {
            timeZone = TimeZone.getTimeZone("Europe/Madrid")
        }
        return sdf.format(Date())
    }

    private fun parseAemetJson(jsonString: String): List<AemetAlert> {
        val results = mutableListOf<AemetAlert>()
        val root = JSONObject(jsonString)
        val ordenAvisos = root.optJSONArray("orden_avisos") ?: return emptyList()

        for (i in 0 until ordenAvisos.length()) {
            val itemArray = ordenAvisos.optJSONArray(i) ?: continue
            if (itemArray.length() < 2) continue

            val alertKey = itemArray.optString(0)
            val alertObj = itemArray.optJSONObject(1) ?: continue

            // The alert key has format: e.g. "2PR-2NA-01PRP1-1789606800-770301"
            val keyParts = alertKey.split("-")
            val zoneCode = keyParts.lastOrNull()?.trim() ?: continue

            // Filter: ONLY Comunitat Valenciana zones (prefixes: 7703 for Alicante, 7712 for Castellón, 7746 for Valencia)
            val provPrefix = zoneCode.take(4)
            val province = when (provPrefix) {
                "7703" -> Province.ALICANTE
                "7712" -> Province.CASTELLON
                "7746" -> Province.VALENCIA
                else -> continue // Discard any zone outside Comunitat Valenciana
            }

            // Official zone name
            val zoneInfo = AemetConstants.CV_ZONES[zoneCode]
            val zoneName = zoneInfo?.second ?: "Zona $zoneCode"

            // Alert level: Amarillo, Naranja, Rojo (do not alter level)
            val severityStr = alertObj.optString("Severity", "").trim()
            val nivelInt = alertObj.optInt("Nivel", -1)
            val level = when {
                severityStr.equals("Rojo", ignoreCase = true) || nivelInt == 1 -> AlertLevel.RED
                severityStr.equals("Naranja", ignoreCase = true) || nivelInt == 2 -> AlertLevel.ORANGE
                severityStr.equals("Amarillo", ignoreCase = true) || nivelInt == 3 -> AlertLevel.YELLOW
                else -> continue // Skip non-warning levels (like green/none)
            }

            // Phenomenon
            val femParam = alertObj.optString("FemParam", "").ifEmpty {
                alertObj.optString("FenParma", "")
            }
            val phenomenon = mapPhenomenon(femParam)

            // Value (Precipitation, wind speed, etc.)
            val rawValue = alertObj.optString("Valor", "").trim()
            val value = if (rawValue.isNotBlank()) rawValue else null

            // Dates
            val onsetRaw = alertObj.optString("Onset", "")
            val expireRaw = alertObj.optString("Expire", "")
            val onsetFormatted = formatAemetDateTime(onsetRaw)
            val expireFormatted = formatAemetDateTime(expireRaw)

            // Description
            val description = alertObj.optString("Descrption", "").ifEmpty {
                alertObj.optString("Description", "")
            }

            // Probability & Certainty
            val probability = alertObj.optString("Prb", "").ifEmpty { null }
            val certainty = alertObj.optString("Certainty", "").ifEmpty { null }

            // Protective recommendations
            val recommendations = getRecommendationsForPhenomenon(phenomenon, level)

            val alert = AemetAlert(
                id = alertKey,
                level = level,
                province = province,
                zoneName = zoneName,
                zoneCode = zoneCode,
                phenomenon = phenomenon,
                description = description,
                value = value,
                probability = probability,
                onsetRaw = onsetRaw,
                onsetFormatted = onsetFormatted,
                expireRaw = expireRaw,
                expireFormatted = expireFormatted,
                certainty = certainty,
                recommendations = recommendations
            )
            results.add(alert)
        }

        return results
    }

    private fun mapPhenomenon(code: String): String {
        val upper = code.uppercase()
        return when {
            upper.startsWith("PRP1") -> "Lluvias (acumulación en 1 hora)"
            upper.startsWith("PRP2") -> "Lluvias (acumulación en 12 horas)"
            upper.startsWith("PR") -> "Precipitaciones y Lluvias"
            upper.startsWith("TO") -> "Tormentas"
            upper.startsWith("VI") -> "Viento (rachas máximas)"
            upper.startsWith("CO") -> "Fenómenos Costeros"
            upper.startsWith("NE") -> "Nevadas"
            upper.startsWith("NI") -> "Nieblas persistentes"
            upper.startsWith("AT") || upper.startsWith("TEM_MAX") -> "Temperaturas Máximas Extremas"
            upper.startsWith("BT") || upper.startsWith("TEM_MIN") -> "Temperaturas Mínimas Extremas"
            upper.startsWith("VS") -> "Polvo en suspensión"
            upper.startsWith("RI") -> "Rissagas"
            upper.startsWith("AL") -> "Aludes"
            upper.startsWith("GA") -> "Galernas"
            upper.startsWith("DH") -> "Deshielos"
            code.isNotBlank() -> code
            else -> "Aviso Meteorológico"
        }
    }

    private fun formatAemetDateTime(isoString: String): String {
        if (isoString.isBlank()) return "No especificada"
        try {
            // Example input: "2026-09-17T03:00:00+02:00"
            val parts = isoString.split("T")
            if (parts.size == 2) {
                val dateParts = parts[0].split("-")
                val timeParts = parts[1].split(":")
                if (dateParts.size == 3 && timeParts.size >= 2) {
                    val day = dateParts[2]
                    val month = dateParts[1]
                    val year = dateParts[0]
                    val hour = timeParts[0]
                    val min = timeParts[1]
                    return "$day/$month/$year $hour:$min"
                }
            }
        } catch (_: Exception) {
            // Fallback
        }
        return isoString
    }

    private fun getRecommendationsForPhenomenon(phenomenon: String, level: AlertLevel): List<String> {
        return when {
            phenomenon.contains("Lluvia", ignoreCase = true) || phenomenon.contains("Precipita", ignoreCase = true) -> {
                listOf(
                    "Evitar circular por carreteras secundarias y pasos subterráneos.",
                    "No cruzar nunca cauces secos, vados ni barrancos ante crecidas repentinas.",
                    "Alejarse de zonas bajas y revisar desagües comunitarios.",
                    "En caso de emergencia vital, llamar inmediatamente al 112."
                )
            }
            phenomenon.contains("Tormenta", ignoreCase = true) -> {
                listOf(
                    "Asegurar puertas, ventanas y retirar objetos de terrazas y balcones.",
                    "Alejarse de estructuras metálicas, árboles aislados y vallas.",
                    "Desconectar aparatos eléctricos para evitar daños por sobretensión.",
                    "Permanecer en el interior de edificaciones seguras."
                )
            }
            phenomenon.contains("Viento", ignoreCase = true) -> {
                listOf(
                    "Retirar macetas y cualquier elemento vulnerable al viento.",
                    "Extremar la precaución al volante, especialmente vehículos pesados o de dos ruedas.",
                    "Alejarse de cornisas, andamios, grúas y arbolado de gran porte."
                )
            }
            phenomenon.contains("Costero", ignoreCase = true) -> {
                listOf(
                    "No acercarse a espigones, rompientes ni paseos marítimos batidos por olas.",
                    "Suspender cualquier actividad náutica o de pesca deportiva.",
                    "Asegurar los amarres de embarcaciones en zonas portuarias."
                )
            }
            phenomenon.contains("Nevada", ignoreCase = true) -> {
                listOf(
                    "Llevar cadenas o neumáticos de invierno en puertos de montaña.",
                    "Disponer de depósito lleno, ropa de abrigo y batería en el móvil.",
                    "Consultar el estado de la red viaria antes de desplazarse."
                )
            }
            else -> {
                listOf(
                    "Seguir atentamente los avisos actualizados de AEMET y Emergències GVA 112.",
                    "Adoptar medidas de autoprotección acordes al nivel de aviso comunicado."
                )
            }
        }
    }
}
