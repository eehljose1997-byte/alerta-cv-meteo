package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudQueue
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DemoDataSource
import com.example.ui.screens.AlertsScreen
import com.example.ui.screens.ForecastScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.MapScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.AlertAmberPrimary
import com.example.ui.theme.AlertLevelRed
import com.example.ui.theme.AlertaCVMeteoTheme
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkOnBackground
import com.example.ui.theme.DarkOnSurfaceVariant
import com.example.ui.theme.DarkOutline
import com.example.ui.theme.DarkSurface

enum class AppNavDestination(
    val titleRes: Int,
    val icon: ImageVector,
    val testTag: String
) {
    INICIO(R.string.nav_inicio, Icons.Default.Home, "nav_tab_inicio"),
    MAPA(R.string.nav_mapa, Icons.Default.Map, "nav_tab_mapa"),
    PREVISION(R.string.nav_prevision, Icons.Default.CloudQueue, "nav_tab_prevision"),
    ALERTAS(R.string.nav_alertas, Icons.Default.Warning, "nav_tab_alertas"),
    AJUSTES(R.string.nav_ajustes, Icons.Default.Settings, "nav_tab_ajustes")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            var isDarkMode by rememberSaveable { mutableStateOf(true) }

            AlertaCVMeteoTheme {
                MainAppScaffold(
                    isDarkMode = isDarkMode,
                    onToggleDarkMode = { isDarkMode = it }
                )
            }
        }
    }
}

@Composable
fun MainAppScaffold(
    isDarkMode: Boolean = true,
    onToggleDarkMode: (Boolean) -> Unit = {}
) {
    var currentDestination by rememberSaveable { mutableStateOf(AppNavDestination.INICIO) }
    val alertsCount = DemoDataSource.demoAlerts.size

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = DarkBackground,
        bottomBar = {
            NavigationBar(
                containerColor = DarkSurface,
                contentColor = DarkOnBackground,
                tonalElevation = 8.dp,
                modifier = Modifier.testTag("bottom_navigation_bar")
            ) {
                AppNavDestination.entries.forEach { destination ->
                    val isSelected = currentDestination == destination

                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { currentDestination = destination },
                        icon = {
                            if (destination == AppNavDestination.ALERTAS && alertsCount > 0) {
                                BadgedBox(
                                    badge = {
                                        Badge(
                                            containerColor = AlertLevelRed,
                                            contentColor = Color.White
                                        ) {
                                            Text(
                                                text = "$alertsCount",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 10.sp
                                            )
                                        }
                                    }
                                ) {
                                    Icon(
                                        imageVector = destination.icon,
                                        contentDescription = stringResource(destination.titleRes),
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                            } else {
                                Icon(
                                    imageVector = destination.icon,
                                    contentDescription = stringResource(destination.titleRes),
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        },
                        label = {
                            Text(
                                text = stringResource(destination.titleRes),
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = AlertAmberPrimary,
                            selectedTextColor = AlertAmberPrimary,
                            unselectedIconColor = DarkOnSurfaceVariant,
                            unselectedTextColor = DarkOnSurfaceVariant,
                            indicatorColor = Color(0xFF1E293B)
                        ),
                        modifier = Modifier.testTag(destination.testTag)
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Crossfade(
                targetState = currentDestination,
                label = "screen_transition"
            ) { destination ->
                when (destination) {
                    AppNavDestination.INICIO -> HomeScreen(
                        onNavigateToAlerts = { currentDestination = AppNavDestination.ALERTAS },
                        onNavigateToMap = { currentDestination = AppNavDestination.MAPA },
                        modifier = Modifier.fillMaxSize()
                    )
                    AppNavDestination.MAPA -> MapScreen(
                        modifier = Modifier.fillMaxSize()
                    )
                    AppNavDestination.PREVISION -> ForecastScreen(
                        modifier = Modifier.fillMaxSize()
                    )
                    AppNavDestination.ALERTAS -> AlertsScreen(
                        modifier = Modifier.fillMaxSize()
                    )
                    AppNavDestination.AJUSTES -> SettingsScreen(
                        isDarkModeEnabled = isDarkMode,
                        onToggleDarkMode = onToggleDarkMode,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }
    }
}

// Retained for tests and backward compatibility
@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(text = "Hello $name!", modifier = modifier)
}

@Preview(showBackground = true)
@Composable
fun AlertaCVMeteoMainPreview() {
    AlertaCVMeteoTheme {
        MainAppScaffold()
    }
}
