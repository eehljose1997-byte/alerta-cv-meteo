package com.example.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Waves
import androidx.compose.material.icons.filled.WindPower
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AlertLevel
import com.example.data.DemoDataSource
import com.example.data.Province
import com.example.ui.theme.AlertAmberPrimary
import com.example.ui.theme.AlertLevelGreen
import com.example.ui.theme.AlertLevelOrange
import com.example.ui.theme.AlertLevelRed
import com.example.ui.theme.AlertLevelYellow
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkOnBackground
import androidx.compose.foundation.layout.heightIn
import com.example.ui.theme.DarkOnSurfaceVariant
import com.example.ui.theme.DarkOutline
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.WeatherAccentCyan

@Composable
fun MapScreen(
    modifier: Modifier = Modifier
) {
    var selectedProvince by remember { mutableStateOf(Province.VALENCIA) }
    val provinceStatus = DemoDataSource.provinceStatuses.find { it.province == selectedProvince }
    val provinceAlerts = DemoDataSource.demoAlerts.filter { it.province == selectedProvince }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = "Mapa Visual de Avisos",
                    color = DarkOnBackground,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Comunitat Valenciana • Vista por Provincias",
                    color = DarkOnSurfaceVariant,
                    fontSize = 13.sp
                )
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF1E293B))
                    .border(1.dp, DarkOutline, RoundedCornerShape(8.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "DEMO",
                    color = AlertAmberPrimary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Province selector buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ProvinceTabPill(
                title = "Castelló",
                level = AlertLevel.ORANGE,
                isSelected = selectedProvince == Province.CASTELLON,
                onClick = { selectedProvince = Province.CASTELLON },
                modifier = Modifier.weight(1f)
            )
            ProvinceTabPill(
                title = "València",
                level = AlertLevel.RED,
                isSelected = selectedProvince == Province.VALENCIA,
                onClick = { selectedProvince = Province.VALENCIA },
                modifier = Modifier.weight(1f)
            )
            ProvinceTabPill(
                title = "Alacant",
                level = AlertLevel.YELLOW,
                isSelected = selectedProvince == Province.ALICANTE,
                onClick = { selectedProvince = Province.ALICANTE },
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Interactive Visual Map Canvas Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("map_canvas_card"),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkOutline)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Representación Geográfica Estilizada",
                    color = DarkOnSurfaceVariant,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Custom Canvas Drawing stylized CV shape with 3 segments
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(260.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF070B14)),
                    contentAlignment = Alignment.Center
                ) {
                    CVMapVisualRepresentation(
                        selectedProvince = selectedProvince,
                        onSelectProvince = { selectedProvince = it }
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Map Legend
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    MapLegendBadge(color = AlertLevelGreen, label = "Sin riesgo")
                    MapLegendBadge(color = AlertLevelYellow, label = "Amarillo")
                    MapLegendBadge(color = AlertLevelOrange, label = "Naranja")
                    MapLegendBadge(color = AlertLevelRed, label = "Rojo")
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Selected Province Detail Card
        provinceStatus?.let { status ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("selected_province_detail"),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, status.maxAlert.color)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.LocationOn,
                                contentDescription = null,
                                tint = status.maxAlert.color,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = status.province.displayName,
                                color = DarkOnBackground,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(status.maxAlert.bgColor)
                                .border(1.dp, status.maxAlert.color, RoundedCornerShape(8.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "${status.maxAlert.emoji} ${status.maxAlert.label.uppercase()}",
                                color = status.maxAlert.color,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = status.summaryText,
                        color = Color(0xFFCBD5E1),
                        fontSize = 13.sp,
                        lineHeight = 18.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Secondary Metrics
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        QuickMetric(
                            icon = Icons.Default.WindPower,
                            title = "Viento Litoral",
                            value = when (status.province) {
                                Province.CASTELLON -> "65-75 km/h"
                                Province.VALENCIA -> "50-70 km/h"
                                Province.ALICANTE -> "35-50 km/h"
                            }
                        )
                        QuickMetric(
                            icon = Icons.Default.Waves,
                            title = "Estado del Mar",
                            value = when (status.province) {
                                Province.CASTELLON -> "Mar gruesa (3.5m)"
                                Province.VALENCIA -> "Fuerte marejada"
                                Province.ALICANTE -> "Marejada (2m)"
                            }
                        )
                    }

                    if (provinceAlerts.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = "Avisos vigentes en esta zona:",
                            color = DarkOnBackground,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            provinceAlerts.forEach { alert ->
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(text = alert.level.emoji, fontSize = 12.sp)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "${alert.zone}: ${alert.phenomenon}",
                                        color = Color(0xFF94A3B8),
                                        fontSize = 12.sp,
                                        maxLines = 1
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
private fun ProvinceTabPill(
    title: String,
    level: AlertLevel,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val borderColor by animateColorAsState(
        targetValue = if (isSelected) level.color else DarkOutline,
        label = "pill_border"
    )
    val bgColor by animateColorAsState(
        targetValue = if (isSelected) DarkSurfaceVariant else DarkSurface,
        label = "pill_bg"
    )

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(bgColor)
            .border(1.dp, borderColor, RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text = level.emoji, fontSize = 12.sp)
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = title,
                color = if (isSelected) DarkOnBackground else DarkOnSurfaceVariant,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                fontSize = 13.sp
            )
        }
    }
}

@Composable
private fun CVMapVisualRepresentation(
    selectedProvince: Province,
    onSelectProvince: (Province) -> Unit
) {
    // Interactive 3-part layout for Castellón (North), Valencia (Center), Alicante (South)
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(vertical = 12.dp, horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceEvenly
    ) {
        // North: Castellón Card
        ProvinceMapSegment(
            province = Province.CASTELLON,
            name = "1. CASTELLÓ",
            subtitle = "Nord • Litoral & Maestrat",
            alertLevel = AlertLevel.ORANGE,
            isSelected = selectedProvince == Province.CASTELLON,
            onClick = { onSelectProvince(Province.CASTELLON) },
            modifier = Modifier.fillMaxWidth(0.75f)
        )

        // Center: Valencia Card
        ProvinceMapSegment(
            province = Province.VALENCIA,
            name = "2. VALÈNCIA",
            subtitle = "Centre • Horta, Ribera & Costera",
            alertLevel = AlertLevel.RED,
            isSelected = selectedProvince == Province.VALENCIA,
            onClick = { onSelectProvince(Province.VALENCIA) },
            modifier = Modifier.fillMaxWidth(0.92f)
        )

        // South: Alicante Card
        ProvinceMapSegment(
            province = Province.ALICANTE,
            name = "3. ALACANT",
            subtitle = "Sud • Marina & Vinalopó",
            alertLevel = AlertLevel.YELLOW,
            isSelected = selectedProvince == Province.ALICANTE,
            onClick = { onSelectProvince(Province.ALICANTE) },
            modifier = Modifier.fillMaxWidth(0.82f)
        )
    }
}

@Composable
private fun ProvinceMapSegment(
    province: Province,
    name: String,
    subtitle: String,
    alertLevel: AlertLevel,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val bg = if (isSelected) alertLevel.bgColor.copy(alpha = 0.9f) else DarkSurfaceVariant.copy(alpha = 0.7f)
    val border = if (isSelected) alertLevel.color else DarkOutline

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(bg)
            .border(if (isSelected) 2.dp else 1.dp, border, RoundedCornerShape(14.dp))
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = name,
                    color = if (isSelected) DarkOnBackground else Color(0xFFCBD5E1),
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                Text(
                    text = subtitle,
                    color = DarkOnSurfaceVariant,
                    fontSize = 10.sp
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(text = alertLevel.emoji, fontSize = 14.sp)
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = alertLevel.label,
                    color = alertLevel.color,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
            }
        }
    }
}

@Composable
private fun MapLegendBadge(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(modifier = Modifier.width(5.dp))
        Text(
            text = label,
            color = DarkOnSurfaceVariant,
            fontSize = 11.sp
        )
    }
}

@Composable
private fun QuickMetric(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    value: String
) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(DarkSurfaceVariant.copy(alpha = 0.6f))
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = WeatherAccentCyan,
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Column {
            Text(text = title, color = DarkOnSurfaceVariant, fontSize = 10.sp)
            Text(text = value, color = DarkOnBackground, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
    }
}
