package com.example.ui.screens

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AlertLevel
import com.example.data.Province
import com.example.data.aemet.AemetAlert
import com.example.data.aemet.AemetAlertsRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

sealed interface AlertsUiState {
    data object Loading : AlertsUiState
    data class Success(
        val alerts: List<AemetAlert>,
        val lastUpdated: String,
        val dayOffset: String
    ) : AlertsUiState
    data class Error(val message: String) : AlertsUiState
}

class AemetAlertsViewModel(
    private val repository: AemetAlertsRepository = AemetAlertsRepository()
) : ViewModel() {

    private val _uiState = MutableStateFlow<AlertsUiState>(AlertsUiState.Loading)
    val uiState: StateFlow<AlertsUiState> = _uiState.asStateFlow()

    private val _selectedProvince = MutableStateFlow<Province?>(null)
    val selectedProvince: StateFlow<Province?> = _selectedProvince.asStateFlow()

    private val _selectedLevel = MutableStateFlow<AlertLevel?>(null)
    val selectedLevel: StateFlow<AlertLevel?> = _selectedLevel.asStateFlow()

    private val _selectedDayOffset = MutableStateFlow("D+0")
    val selectedDayOffset: StateFlow<String> = _selectedDayOffset.asStateFlow()

    private val _selectedAlertForDetail = MutableStateFlow<AemetAlert?>(null)
    val selectedAlertForDetail: StateFlow<AemetAlert?> = _selectedAlertForDetail.asStateFlow()

    init {
        loadAlerts("D+0")
    }

    fun selectAlertForDetail(alert: AemetAlert?) {
        _selectedAlertForDetail.value = alert
    }

    fun setProvinceFilter(province: Province?) {
        _selectedProvince.value = province
    }

    fun setLevelFilter(level: AlertLevel?) {
        _selectedLevel.value = level
    }

    fun setDayOffset(offset: String) {
        if (_selectedDayOffset.value != offset) {
            _selectedDayOffset.value = offset
            loadAlerts(offset)
        }
    }

    fun refresh() {
        loadAlerts(_selectedDayOffset.value)
    }

    fun loadAlerts(dayOffset: String = "D+0") {
        viewModelScope.launch {
            _uiState.value = AlertsUiState.Loading
            val result = repository.fetchValencianAlerts(dayOffset)
            result.fold(
                onSuccess = { list ->
                    val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
                    val updatedStr = "Actualizado: hoy a las ${timeFormat.format(Date())}"
                    _uiState.value = AlertsUiState.Success(
                        alerts = list,
                        lastUpdated = updatedStr,
                        dayOffset = dayOffset
                    )
                },
                onFailure = { error ->
                    _uiState.value = AlertsUiState.Error(
                        error.localizedMessage ?: "No se pudo conectar con el servidor oficial de AEMET"
                    )
                }
            )
        }
    }
}
