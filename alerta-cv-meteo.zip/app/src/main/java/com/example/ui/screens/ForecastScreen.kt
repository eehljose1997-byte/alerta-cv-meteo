package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Air
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DailyForecast
import com.example.data.DemoDataSource
import com.example.data.HourlyForecast
import com.example.ui.theme.AlertAmberPrimary
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkOnBackground
import com.example.ui.theme.DarkOnSurfaceVariant
import com.example.ui.theme.DarkOutline
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.WeatherAccentCyan

@Composable
fun ForecastScreen(
    modifier: Modifier = Modifier
) {
    val municipalities = listOf(
        "València",
        "Castelló",
        "Alacant",
        "Gandia",
        "Morella",
        "Alcoi"
    )
    var selectedCityIndex by remember { mutableIntStateOf(0) }
    val currentCity = municipalities[selectedCityIndex]

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
            .verticalScroll(rememberScrollState())
            .padding(top = 16.dp, bottom = 24.dp)
    ) {
        // Top Header
        Column(modifier = Modifier.padding(horizontal = 20.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Previsión del Tiempo",
                    color = DarkOnBackground,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold
                )

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF1E293B))
                        .border(1.dp, DarkOutline, RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "DEMO",
                        color = AlertAmberPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Text(
                text = "Simulación meteorológica para la Comunitat Valenciana",
                color = DarkOnSurfaceVariant,
                fontSize = 13.sp
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Municipalities Horizontal Tabs
        ScrollableTabRow(
            selectedTabIndex = selectedCityIndex,
            containerColor = DarkBackground,
            contentColor = AlertAmberPrimary,
            edgePadding = 20.dp,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedCityIndex]),
                    color = AlertAmberPrimary
                )
            },
            divider = {}
        ) {
            municipalities.forEachIndexed { index, city ->
                Tab(
                    selected = selectedCityIndex == index,
                    onClick = { selectedCityIndex = index },
                    text = {
                        Text(
                            text = city,
                            color = if (selectedCityIndex == index) AlertAmberPrimary else DarkOnSurfaceVariant,
                            fontWeight = if (selectedCityIndex == index) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 14.sp
                        )
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Hero Weather Card
        Box(modifier = Modifier.padding(horizontal = 20.dp)) {
            HeroWeatherCard(city = currentCity)
        }

        Spacer(modifier = Modifier.height(22.dp))

        // Hourly Forecast Section
        Column(modifier = Modifier.padding(horizontal = 20.dp)) {
            Text(
                text = "Pronóstico por Horas",
                color = DarkOnBackground,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Evolución para hoy en $currentCity",
                color = DarkOnSurfaceVariant,
                fontSize = 12.sp
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(DemoDataSource.hourlyDemo) { hourItem ->
                HourlyItemCard(item = hourItem)
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // 5-Day Forecast Section
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
        ) {
            Text(
                text = "Previsión 5 Días",
                color = DarkOnBackground,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(10.dp))

            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkOutline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    DemoDataSource.dailyDemo.forEachIndexed { index, dayItem ->
                        DailyItemRow(item = dayItem)
                        if (index < DemoDataSource.dailyDemo.size - 1) {
                            androidx.compose.material3.HorizontalDivider(
                                color = DarkOutline.copy(alpha = 0.5f),
                                modifier = Modifier.padding(vertical = 8.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Notice badge
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(DarkSurfaceVariant.copy(alpha = 0.6f))
                    .padding(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = AlertAmberPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Datos climáticos de ejemplo para validación funcional.",
                        color = DarkOnSurfaceVariant,
                        fontSize = 11.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun HeroWeatherCard(city: String) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("hero_weather_card"),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF334155))
    ) {
        Column(
            modifier = Modifier
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xFF1E293B), DarkSurface)
                    )
                )
                .padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = city,
                        color = DarkOnBackground,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Comunitat Valenciana",
                        color = DarkOnSurfaceVariant,
                        fontSize = 13.sp
                    )
                }
                Text(text = "⛈️", fontSize = 42.sp)
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.Top) {
                    Text(
                        text = "18°",
                        color = DarkOnBackground,
                        fontSize = 48.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        text = "C",
                        color = AlertAmberPrimary,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "Lluvia y Tormentas",
                        color = DarkOnBackground,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 15.sp
                    )
                    Text(
                        text = "Sensación: 17°C • Máx: 21° / Mín: 14°",
                        color = DarkOnSurfaceVariant,
                        fontSize = 12.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Weather parameters row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(DarkBackground.copy(alpha = 0.6f))
                    .padding(vertical = 10.dp, horizontal = 14.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                WeatherParam(icon = Icons.Default.WaterDrop, label = "Lluvia", value = "95%")
                WeatherParam(icon = Icons.Default.Air, label = "Viento", value = "45 km/h")
                WeatherParam(icon = Icons.Default.WbSunny, label = "Índice UV", value = "2 (Bajo)")
                WeatherParam(icon = Icons.Default.Thermostat, label = "Humedad", value = "88%")
            }
        }
    }
}

@Composable
private fun WeatherParam(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = WeatherAccentCyan,
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(text = label, color = DarkOnSurfaceVariant, fontSize = 10.sp)
        Text(text = value, color = DarkOnBackground, fontWeight = FontWeight.Bold, fontSize = 11.sp)
    }
}

@Composable
private fun HourlyItemCard(item: HourlyForecast) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkOutline),
        modifier = Modifier.width(76.dp)
    ) {
        Column(
            modifier = Modifier.padding(vertical = 12.dp, horizontal = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = item.time,
                color = DarkOnSurfaceVariant,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(text = item.icon, fontSize = 22.sp)
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = item.temp,
                color = DarkOnBackground,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = item.pop,
                color = WeatherAccentCyan,
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
private fun DailyItemRow(item: DailyForecast) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.width(90.dp)) {
            Text(
                text = item.day,
                color = DarkOnBackground,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
            Text(
                text = item.dateText,
                color = DarkOnSurfaceVariant,
                fontSize = 11.sp
            )
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f),
            horizontalArrangement = Arrangement.Center
        ) {
            Text(text = item.pop, color = WeatherAccentCyan, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = item.condition,
                color = Color(0xFFCBD5E1),
                fontSize = 12.sp,
                maxLines = 1
            )
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = item.tempMax,
                color = DarkOnBackground,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
            )
            Text(
                text = " / ${item.tempMin}",
                color = DarkOnSurfaceVariant,
                fontSize = 12.sp
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = item.alertLevel.emoji, fontSize = 12.sp)
        }
    }
}
