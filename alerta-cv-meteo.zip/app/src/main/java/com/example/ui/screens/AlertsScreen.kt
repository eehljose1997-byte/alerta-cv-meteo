package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.ArrowDropUp
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.AlertLevel
import com.example.data.Province
import com.example.data.aemet.AemetAlert
import com.example.data.aemet.AemetConstants
import com.example.ui.theme.AlertAmberPrimary
import com.example.ui.theme.AlertBgGreen
import com.example.ui.theme.AlertLevelGreen
import com.example.ui.theme.AlertLevelOrange
import com.example.ui.theme.AlertLevelRed
import com.example.ui.theme.AlertLevelYellow
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkOnBackground
import com.example.ui.theme.DarkOnSurfaceVariant
import com.example.ui.theme.DarkOutline
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.WeatherAccentCyan

@Composable
fun AlertsScreen(
    modifier: Modifier = Modifier,
    viewModel: AemetAlertsViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val selectedProvince by viewModel.selectedProvince.collectAsState()
    val selectedLevel by viewModel.selectedLevel.collectAsState()
    val selectedDayOffset by viewModel.selectedDayOffset.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
            .padding(top = 16.dp)
    ) {
        // Screen Header
        Column(modifier = Modifier.padding(horizontal = 20.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "Avisos Meteorológicos",
                        color = DarkOnBackground,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Comunitat Valenciana",
                        color = DarkOnSurfaceVariant,
                        fontSize = 13.sp
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Official AEMET Badge
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF0369A1).copy(alpha = 0.25f))
                            .border(1.dp, Color(0xFF38BDF8), RoundedCornerShape(8.dp))
                            .padding(horizontal = 9.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = AemetConstants.SOURCE_LABEL,
                            color = Color(0xFF38BDF8),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 0.3.sp
                        )
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    IconButton(
                        onClick = { viewModel.refresh() },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Actualizar avisos AEMET",
                            tint = DarkOnSurfaceVariant,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Day Selector: Hoy / Mañana
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(DarkSurfaceVariant.copy(alpha = 0.6f))
                    .padding(4.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                DayTabButton(
                    title = "Hoy (D+0)",
                    selected = selectedDayOffset == "D+0",
                    onClick = { viewModel.setDayOffset("D+0") },
                    modifier = Modifier.weight(1f)
                )
                Spacer(modifier = Modifier.width(4.dp))
                DayTabButton(
                    title = "Mañana (D+1)",
                    selected = selectedDayOffset == "D+1",
                    onClick = { viewModel.setDayOffset("D+1") },
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Warning Levels Legend
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(DarkSurfaceVariant.copy(alpha = 0.4f))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                LegendItem(emoji = "🟡", text = "Amarillo", sub = "Riesgo")
                LegendItem(emoji = "🟠", text = "Naranja", sub = "Importante")
                LegendItem(emoji = "🔴", text = "Rojo", sub = "Extraordinario")
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Province Selector (Castellón, Valencia, Alicante)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                ProvinceFilterChip(
                    label = "Todas",
                    selected = selectedProvince == null,
                    onClick = { viewModel.setProvinceFilter(null) },
                    modifier = Modifier.weight(1f)
                )
                ProvinceFilterChip(
                    label = "Castellón",
                    selected = selectedProvince == Province.CASTELLON,
                    onClick = {
                        viewModel.setProvinceFilter(
                            if (selectedProvince == Province.CASTELLON) null else Province.CASTELLON
                        )
                    },
                    modifier = Modifier.weight(1f)
                )
                ProvinceFilterChip(
                    label = "Valencia",
                    selected = selectedProvince == Province.VALENCIA,
                    onClick = {
                        viewModel.setProvinceFilter(
                            if (selectedProvince == Province.VALENCIA) null else Province.VALENCIA
                        )
                    },
                    modifier = Modifier.weight(1f)
                )
                ProvinceFilterChip(
                    label = "Alicante",
                    selected = selectedProvince == Province.ALICANTE,
                    onClick = {
                        viewModel.setProvinceFilter(
                            if (selectedProvince == Province.ALICANTE) null else Province.ALICANTE
                        )
                    },
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Severity Filter Chips
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                item {
                    FilterChip(
                        selected = selectedLevel == null,
                        onClick = { viewModel.setLevelFilter(null) },
                        label = { Text("Todos los niveles") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = AlertAmberPrimary,
                            selectedLabelColor = Color(0xFF0F172A),
                            containerColor = DarkSurface,
                            labelColor = DarkOnSurfaceVariant
                        )
                    )
                }
                item {
                    FilterChip(
                        selected = selectedLevel == AlertLevel.RED,
                        onClick = {
                            viewModel.setLevelFilter(
                                if (selectedLevel == AlertLevel.RED) null else AlertLevel.RED
                            )
                        },
                        label = { Text("🔴 Rojo") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = AlertLevelRed,
                            selectedLabelColor = Color.White,
                            containerColor = DarkSurface,
                            labelColor = DarkOnSurfaceVariant
                        )
                    )
                }
                item {
                    FilterChip(
                        selected = selectedLevel == AlertLevel.ORANGE,
                        onClick = {
                            viewModel.setLevelFilter(
                                if (selectedLevel == AlertLevel.ORANGE) null else AlertLevel.ORANGE
                            )
                        },
                        label = { Text("🟠 Naranja") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = AlertLevelOrange,
                            selectedLabelColor = Color.White,
                            containerColor = DarkSurface,
                            labelColor = DarkOnSurfaceVariant
                        )
                    )
                }
                item {
                    FilterChip(
                        selected = selectedLevel == AlertLevel.YELLOW,
                        onClick = {
                            viewModel.setLevelFilter(
                                if (selectedLevel == AlertLevel.YELLOW) null else AlertLevel.YELLOW
                            )
                        },
                        label = { Text("🟡 Amarillo") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = AlertLevelYellow,
                            selectedLabelColor = Color(0xFF0F172A),
                            containerColor = DarkSurface,
                            labelColor = DarkOnSurfaceVariant
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Content Area based on UiState
        when (val state = uiState) {
            is AlertsUiState.Loading -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        CircularProgressIndicator(
                            color = AlertAmberPrimary,
                            strokeWidth = 3.dp,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(18.dp))
                        Text(
                            text = "Consultando avisos oficiales de AEMET...",
                            color = DarkOnBackground,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Comunitat Valenciana: Castellón, Valencia y Alicante",
                            color = DarkOnSurfaceVariant,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }

            is AlertsUiState.Error -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = DarkSurface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, AlertLevelOrange.copy(alpha = 0.5f))
                    ) {
                        Column(
                            modifier = Modifier.padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = null,
                                tint = AlertLevelOrange,
                                modifier = Modifier.size(40.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "No se pudo conectar con AEMET",
                                color = DarkOnBackground,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = state.message,
                                color = DarkOnSurfaceVariant,
                                fontSize = 13.sp,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(
                                onClick = { viewModel.refresh() },
                                colors = ButtonDefaults.buttonColors(containerColor = AlertAmberPrimary),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = null,
                                    tint = Color(0xFF0F172A),
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Reintentar conexión",
                                    color = Color(0xFF0F172A),
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            is AlertsUiState.Success -> {
                // Filter strictly by selected province and level
                val filteredAlerts = state.alerts.filter { alert ->
                    (selectedProvince == null || alert.province == selectedProvince) &&
                    (selectedLevel == null || alert.level == selectedLevel)
                }

                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Update timestamp & count
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = state.lastUpdated,
                                color = DarkOnSurfaceVariant,
                                fontSize = 12.sp
                            )
                            Text(
                                text = "${filteredAlerts.size} avisos activos",
                                color = if (filteredAlerts.isNotEmpty()) AlertAmberPrimary else AlertLevelGreen,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    if (filteredAlerts.isEmpty()) {
                        item {
                            NoAlertsActiveCard(province = selectedProvince)
                        }
                    } else {
                        items(filteredAlerts, key = { it.id }) { alert ->
                            AemetAlertCard(alert = alert)
                        }
                    }

                    item {
                        Spacer(modifier = Modifier.height(10.dp))
                        OfficialAemetFooterNotice()
                        Spacer(modifier = Modifier.height(24.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun DayTabButton(
    title: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (selected) AlertAmberPrimary else Color.Transparent)
            .clickable { onClick() }
            .padding(vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = title,
            color = if (selected) Color(0xFF0F172A) else DarkOnSurfaceVariant,
            fontSize = 12.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
        )
    }
}

@Composable
private fun ProvinceFilterChip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (selected) Color(0xFF334155) else DarkSurface)
            .border(
                1.dp,
                if (selected) AlertAmberPrimary else DarkOutline.copy(alpha = 0.5f),
                RoundedCornerShape(8.dp)
            )
            .clickable { onClick() }
            .padding(vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = if (selected) AlertAmberPrimary else DarkOnSurfaceVariant,
            fontSize = 12.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun LegendItem(emoji: String, text: String, sub: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(text = emoji, fontSize = 14.sp)
        Spacer(modifier = Modifier.width(6.dp))
        Column {
            Text(
                text = text,
                color = DarkOnBackground,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = sub,
                color = DarkOnSurfaceVariant,
                fontSize = 9.sp
            )
        }
    }
}

@Composable
private fun NoAlertsActiveCard(province: Province?) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("no_alerts_card")
            .padding(vertical = 16.dp),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = androidx.compose.foundation.BorderStroke(1.5.dp, AlertLevelGreen.copy(alpha = 0.6f))
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(AlertBgGreen),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = AlertLevelGreen,
                    modifier = Modifier.size(32.dp)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Exact required text
            Text(
                text = AemetConstants.NO_ALERTS_MESSAGE,
                color = DarkOnBackground,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(6.dp))

            val subtitle = if (province != null) {
                "En la provincia de ${province.displayName}"
            } else {
                "En el territorio de la Comunitat Valenciana"
            }
            Text(
                text = subtitle,
                color = DarkOnSurfaceVariant,
                fontSize = 13.sp,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(12.dp))

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF0369A1).copy(alpha = 0.2f))
                    .border(1.dp, Color(0xFF38BDF8).copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Text(
                    text = AemetConstants.SOURCE_LABEL,
                    color = Color(0xFF38BDF8),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun AemetAlertCard(alert: AemetAlert) {
    var expanded by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("aemet_alert_card_${alert.id}")
            .animateContentSize(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = androidx.compose.foundation.BorderStroke(1.5.dp, alert.level.color.copy(alpha = 0.7f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header Row: Severity Badge + Province Tag
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Colored Severity Badge (Amarillo, Naranja, Rojo)
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(alert.level.bgColor)
                        .border(1.dp, alert.level.color.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(text = alert.level.emoji, fontSize = 13.sp)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "AVISO ${alert.level.label.uppercase()}",
                            color = alert.level.color,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 11.sp,
                            letterSpacing = 0.5.sp
                        )
                    }
                }

                // Province Tag (Castellón, Valencia, Alicante)
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xFF334155))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = alert.province.shortName.uppercase(),
                        color = Color(0xFFE2E8F0),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Phenomenon
            Text(
                text = alert.phenomenon,
                color = DarkOnBackground,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                lineHeight = 22.sp
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Exact Zone from AEMET
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.LocationOn,
                    contentDescription = null,
                    tint = alert.level.color,
                    modifier = Modifier.size(15.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = alert.zoneName,
                    color = alert.level.color,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Official Description from AEMET
            if (alert.description.isNotBlank()) {
                Text(
                    text = alert.description,
                    color = Color(0xFFE2E8F0),
                    fontSize = 13.sp,
                    lineHeight = 19.sp
                )
                Spacer(modifier = Modifier.height(10.dp))
            }

            // Value (Precipitation / Wind speed) when provided by AEMET
            if (!alert.value.isNullOrBlank()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(DarkSurfaceVariant.copy(alpha = 0.7f))
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Speed,
                        contentDescription = null,
                        tint = alert.level.color,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Valor AEMET: ${alert.value}",
                        color = DarkOnBackground,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
            }

            // Start and End Dates/Times
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(DarkSurfaceVariant.copy(alpha = 0.4f))
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.AccessTime,
                        contentDescription = null,
                        tint = DarkOnSurfaceVariant,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Inicio: ${alert.onsetFormatted}",
                        color = DarkOnBackground,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.AccessTime,
                        contentDescription = null,
                        tint = DarkOnSurfaceVariant,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Fin: ${alert.expireFormatted}",
                        color = DarkOnBackground,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                if (!alert.probability.isNullOrBlank()) {
                    Text(
                        text = "Probabilidad: ${alert.probability}",
                        color = DarkOnSurfaceVariant,
                        fontSize = 11.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Official Source Badge inside Card
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = AemetConstants.SOURCE_LABEL,
                    color = Color(0xFF38BDF8),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )

                if (!alert.certainty.isNullOrBlank()) {
                    Text(
                        text = "Estado: ${alert.certainty}",
                        color = DarkOnSurfaceVariant,
                        fontSize = 11.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            HorizontalDivider(color = DarkOutline.copy(alpha = 0.5f))

            // Expandable Self-protection recommendations (112 CV)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { expanded = !expanded }
                    .padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = null,
                        tint = AlertAmberPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (expanded) "Ocultar recomendaciones 112" else "Ver recomendaciones 112 Comunitat Valenciana",
                        color = AlertAmberPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                Icon(
                    imageVector = if (expanded) Icons.Default.ArrowDropUp else Icons.Default.ArrowDropDown,
                    contentDescription = null,
                    tint = AlertAmberPrimary
                )
            }

            if (expanded) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    alert.recommendations.forEach { recommendation ->
                        Row(
                            verticalAlignment = Alignment.Top,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "• ",
                                color = alert.level.color,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Text(
                                text = recommendation,
                                color = Color(0xFFCBD5E1),
                                fontSize = 12.sp,
                                lineHeight = 17.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun OfficialAemetFooterNotice() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF0369A1).copy(alpha = 0.12f))
            .border(1.dp, Color(0xFF0284C7).copy(alpha = 0.35f), RoundedCornerShape(12.dp))
            .padding(14.dp)
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = null,
                    tint = Color(0xFF38BDF8),
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = AemetConstants.SOURCE_FULL,
                    color = DarkOnBackground,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Información meteorológica oficial de la Agencia Estatal de Meteorología para la Comunitat Valenciana. No se modifican niveles ni se amplían zonas. Ante emergencias llame al 112.",
                color = DarkOnSurfaceVariant,
                fontSize = 11.sp,
                lineHeight = 16.sp
            )
        }
    }
}
