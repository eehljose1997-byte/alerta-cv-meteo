package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val AlertAmberPrimary = Color(0xFFF59E0B)
val AlertAmberOnPrimary = Color(0xFF0F172A)
val AlertAmberContainer = Color(0xFF2E2413)
val AlertAmberOnContainer = Color(0xFFFDE68A)

val DarkBackground = Color(0xFF090D16)
val DarkSurface = Color(0xFF0F172A)
val DarkSurfaceVariant = Color(0xFF1E293B)
val DarkSurfaceHighlight = Color(0xFF273549)

val DarkOnBackground = Color(0xFFF8FAFC)
val DarkOnSurface = Color(0xFFF1F5F9)
val DarkOnSurfaceVariant = Color(0xFF94A3B8)
val DarkOutline = Color(0xFF334155)

val WeatherAccentCyan = Color(0xFF38BDF8)
val WeatherAccentOrange = Color(0xFFFB923C)
val WeatherAccentGreen = Color(0xFF34D399)

// Official Meteorological Alert Levels
val AlertLevelGreen = Color(0xFF22C55E)
val AlertLevelYellow = Color(0xFFEAB308)
val AlertLevelOrange = Color(0xFFF97316)
val AlertLevelRed = Color(0xFFEF4444)

val AlertBgYellow = Color(0xFF2D2406)
val AlertBgOrange = Color(0xFF351A08)
val AlertBgRed = Color(0xFF360C0C)
val AlertBgGreen = Color(0xFF0C2919)
