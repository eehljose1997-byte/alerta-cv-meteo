package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Alerta CV Meteo", appName)
  }

  @Test
  fun `verify navigation tabs and provinces exist`() {
    assertEquals(5, AppNavDestination.entries.size)
    val context = ApplicationProvider.getApplicationContext<Context>()
    assertEquals("Inicio", context.getString(R.string.nav_inicio))
    assertEquals("Mapa", context.getString(R.string.nav_mapa))
    assertEquals("Previsión", context.getString(R.string.nav_prevision))
    assertEquals("Alertas", context.getString(R.string.nav_alertas))
    assertEquals("Ajustes", context.getString(R.string.nav_ajustes))
  }

  @Test
  fun `verify AEMET constants and Comunitat Valenciana zones`() {
    assertEquals("Fuente: AEMET", com.example.data.aemet.AemetConstants.SOURCE_LABEL)
    assertEquals("No hay avisos meteorológicos activos", com.example.data.aemet.AemetConstants.NO_ALERTS_MESSAGE)

    // Check that Alicante, Castellón and Valencia zones are properly registered
    val zones = com.example.data.aemet.AemetConstants.CV_ZONES
    val alicanteZone = zones["770301"]
    org.junit.Assert.assertNotNull(alicanteZone)
    assertEquals(com.example.data.Province.ALICANTE, alicanteZone?.first)
    assertEquals("Litoral norte de Alicante", alicanteZone?.second)

    val valenciaZone = zones["774604"]
    org.junit.Assert.assertNotNull(valenciaZone)
    assertEquals(com.example.data.Province.VALENCIA, valenciaZone?.first)
    assertEquals("Litoral sur de Valencia", valenciaZone?.second)

    val castellonZone = zones["771201"]
    org.junit.Assert.assertNotNull(castellonZone)
    assertEquals(com.example.data.Province.CASTELLON, castellonZone?.first)
    assertEquals("Interior norte de Castellón", castellonZone?.second)
  }

  @Test
  fun `verify AEMET alert levels match requirement`() {
    assertEquals("Amarillo", com.example.data.AlertLevel.YELLOW.label)
    assertEquals("Naranja", com.example.data.AlertLevel.ORANGE.label)
    assertEquals("Rojo", com.example.data.AlertLevel.RED.label)
  }
}
